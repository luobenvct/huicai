<template>
	<div class="loading">
		正在拼命加载中...
	</div>
</template>

<script>
	export default {
		name: 'loading',
		data () {
			return {

			}
		},
		methods:{

		}
	}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
	
</style>
