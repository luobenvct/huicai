module.exports = {
  NODE_ENV: '"production"',
  API_ROOT : process.env.API_ROOT
}
